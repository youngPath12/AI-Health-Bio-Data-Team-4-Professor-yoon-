# Brain Age 모델 카드

모델: ElasticNet
예측 목표: PHC_Age_T1(실제 연령)
훈련 집단: 참가자별 최초 적격 T1을 가진 CN만 사용
입력: ComBat FreeSurfer ROI 191개 + 성별 + ICV
분할: 연령 삼분위와 성별을 층화한 CN 70/15/15 훈련/검증/테스트
BAG 보정: CN 검증 집합의 역선형 연령 편향 보정
임상군 분석: CN 테스트 대비 MCI/AD의 BAG를 연령·성별·ICV 보정 ANCOVA로 비교
용도 제한: 개인 임상 진단이나 개인별 위험 확정에 사용하지 않음.
