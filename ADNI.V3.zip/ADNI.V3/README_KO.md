# ADNI Brain Age Gap V3 통합 프로젝트

## 프로젝트 목적

이 폴더는 ADNI의 T1 MRI FreeSurfer 요약 지표로부터 **뇌 연령(brain age)** 을 예측하고, 실제 연령과의 차이인 **BAG(Brain Age Gap)** 를 계산하는 재현 가능한 연구용 분석 프로젝트입니다. 한 개의 주피터 노트북에서 원자료 확인, 전처리, 모델 학습, 독립 성능 검증, 통계적 유의성 검정, 임상군 비교, BAG-연관 피질 지도, 그리고 ADNI 개인별 3D 피질 지도를 순서대로 수행합니다.

이 결과는 연구 및 탐색 목적입니다. 개인의 치매 진단, 전환 위험 확정, 치료 결정에는 사용할 수 없습니다.

## 폴더 구조

```text
ADNI.V3/
├─ ADNI_Brain_Age_Gap_V3_Integrated.ipynb  # 전체 분석을 실행하는 유일한 노트북
├─ README_KO.md                             # 이 설명서
├─ requirements.txt                         # Python 3.14 호환 패키지 범위
├─ assets/fsaverage5/                       # 표준 뇌 표면 및 Desikan-Killiany annotation
├─ modeling_data/                           # 노트북이 만드는 개인 모델링용 데이터
│  ├─ adni_personal_modeling_cohort.csv
│  ├─ adni_person_catalog.csv
│  ├─ data_dictionary.csv
│  └─ README_KO.md
└─ outputs/                                 # 모델, 표, 그림, 3D HTML 결과
   ├─ figures/
   └─ personal_maps/
```

원본 자료는 이 폴더에 복사하지 않습니다. 노트북은 바탕화면의 `ADNI_data/ADSP_PHC/ADSP_PHC_T1_FS_22Jan2026.csv` 및 `ADNI_data/Assessments/DXSUM_22Jan2026.csv`를 읽기 전용으로 사용합니다. ADNI 배포 제한을 준수하기 위해 개인 식별자가 들어 있는 `modeling_data`와 `outputs/personal_maps`는 외부에 재배포하지 않아야 합니다.

## 주요 용어

| 용어 | 뜻 |
|---|---|
| T1 MRI | 해부학적 T1 강조 자기공명영상입니다. |
| FreeSurfer ROI | FreeSurfer가 뇌를 영역(ROI, region of interest)별로 분할해 계산한 피질 두께·부피·피질하 부피 등의 요약값입니다. |
| ComBat | 스캐너/배치 차이에 따른 체계적 차이를 줄이기 위해 원자료에 이미 적용된 조화(harmonization) 처리입니다. 이 프로젝트는 `_combat` 열을 사용합니다. |
| CN / MCI / AD | 각각 인지정상, 경도인지장애, 알츠하이머병 진단군입니다. |
| Chronological age | 촬영 시점의 실제 연령(`PHC_Age_T1`)입니다. |
| Predicted brain age | MRI ROI로 모델이 예측한 뇌 연령입니다. |
| Raw BAG | 보정 전 `예측 뇌 연령 - 실제 연령`입니다. |
| Corrected BAG | CN 검증 집합에서 추정한 연령 편향을 보정한 BAG입니다. 양수이면 실제 연령보다 뇌가 더 늙게 예측된 방향입니다. |
| ICV | 두개강내 용적(intracranial volume)입니다. 머리 크기 차이를 보정하는 공변량입니다. |
| RID | ADNI 연구용 참가자 ID입니다. RID는 연속 번호가 아니며, 일부 번호의 부재는 오류가 아닙니다. |
| thinning_z | 같은 연령·성별 CN 기준에서 개인의 피질 두께가 기대치보다 얼마나 낮은지 나타내는 표준화 점수입니다. 양수일수록 더 얇은 방향입니다. |
| fsaverage5 | 개인 MRI가 아니라 FreeSurfer의 표준 피질 표면 템플릿입니다. ADNI CSV에는 개인별 pial 표면 파일이 없으므로 기본 3D 지도는 이 템플릿 위에 개인 ROI 값을 투영합니다. |

## 사용 데이터와 분석 단위

### 원자료

`ADSP_PHC_T1_FS_22Jan2026.csv`의 ComBat 처리 FreeSurfer 지표를 사용합니다. 피질 두께·피질/피질하 부피·CSF/뇌실 계열을 포함한 ROI와 성별, ICV가 뇌 연령 모델의 입력입니다. 진단, RID, PTID, 촬영일은 뇌 연령 예측 입력에 넣지 않습니다. 진단을 모델 입력으로 사용하면 질병군의 BAG 차이를 독립적으로 비교할 수 없고, RID 같은 식별자를 쓰면 정보 누수가 발생할 수 있기 때문입니다.

MCI 종단 분석에는 `DXSUM_22Jan2026.csv`를 사용합니다. MRI 후 30일을 넘긴 진단 기록 중 730일 이내 AD 전환 여부를 정의하며, 전환하지 않은 사람은 적어도 730일의 추적관찰이 있을 때만 비교군에 포함합니다.

### 분석 단위와 반복 방문 처리

한 RID에서 결측이 없는 **가장 이른 적격 T1 검사 한 건**만 선택합니다. 따라서 같은 사람이 훈련·검증·테스트에 동시에 포함되는 누수를 막고, 개인별 3D 모델링에서도 한 RID당 한 행을 사용합니다. RID 1, 3처럼 중간 번호가 없을 수 있는 이유는 ADNI의 RID 체계 자체가 연속적이지 않고, 해당 RID가 원자료에 없거나 필수 값이 없는 경우가 있기 때문입니다.

## 전처리와 결측 처리

노트북은 다음을 명시적으로 점검합니다.

1. 촬영일, RID, 실제 연령, 성별, 유효 진단(CN/MCI/AD), 모든 모델 입력 ROI가 존재하는지 검사합니다.
2. 수치형 ROI의 비유한값(inf, -inf), 결측 수, 연령·성별·ICV 범위, 중복 RID, 분할 누수를 보고합니다.
3. 기본 분석 코호트는 위 필수값이 모두 있는 완전 사례만 사용합니다. MRI ROI의 결측을 임의 평균으로 채우면 영상 처리 실패나 품질 문제를 정상값으로 바꿀 수 있기 때문입니다.
4. 모델 파이프라인 안에는 중앙값 대치 단계를 남겨 둡니다. 이는 향후 새 자료에 단일 ROI 결측이 있을 때 실행이 중단되지 않게 하기 위한 것으로, 교차검증 각 fold 안에서만 학습되어 누수를 만들지 않습니다.
5. 원자료에는 motion 또는 FreeSurfer segmentation pass/fail 같은 명시적 영상 QC 열이 없으므로, 통계적으로 극단적인 값이라는 이유만으로 대상을 자동 제외하지 않습니다. 실제 질병 관련 구조 차이를 QC 오류로 잘못 제거하지 않기 위해서입니다. 영상 수준 QC 파일이 추가되면 분석 전 해당 pass/fail 기준을 적용해야 합니다.

## 뇌 연령 모델

### 왜 CN만 학습하는가

뇌 연령의 정상 노화 기준선을 만들기 위해 CN 참가자만으로 학습합니다. MCI와 AD는 훈련에 넣지 않고, 학습 후 BAG를 계산하여 CN 독립 테스트와 비교합니다.

### 분할과 후보 모델

CN은 연령 삼분위와 성별을 함께 층화하여 RID 단위로 70% 훈련, 15% 검증, 15% 독립 테스트로 나눕니다. ROI는 서로 강하게 상관되므로 계수를 안정화하는 Ridge(L2 규제)를 기본 후보로 두고, 일부 ROI 계수를 줄일 수 있는 Elastic Net도 후보로 둡니다. 각 후보의 하이퍼파라미터는 훈련 집합 내부 5겹 교차검증으로 찾고, 후보 선택은 검증 CN의 MAE로만 합니다. 독립 테스트는 모델 선택에 사용하지 않습니다.

### BAG 보정

뇌 연령 모델에는 실제 연령에 따라 과대·과소예측되는 편향이 흔합니다. 검증 CN에서 `예측 뇌 연령 = a + b × 실제 연령`을 적합한 뒤, `(예측 뇌 연령 - a) / b`로 보정 예측 연령을 구하고 실제 연령을 빼서 corrected BAG를 계산합니다. 이 보정 계수는 고정한 뒤 독립 CN, MCI, AD에 동일하게 적용합니다.

## 성능과 유의성 해석

노트북은 독립 CN 테스트에서 MAE, RMSE, R²와 부트스트랩 95% 신뢰구간을 계산합니다. R²는 실제 연령 분산 중 모델이 설명한 비율이며, R² 자체는 p값이 아닙니다. 따라서 훈련 연령을 500회 무작위로 섞은 순열 모델보다 관측된 R²가 큰지, MAE가 작은지를 함께 검사합니다. 순열 p값이 0.05보다 작으면 현재 데이터와 이 검증 설계에서 우연 기준보다 좋은 예측 연관성이 있다는 뜻입니다. 이것은 외부 코호트 일반화나 임상적 유용성을 보장하지 않습니다.

임상군 비교는 `corrected_BAG ~ group + chronological_age + sex + ICV`의 HC3 강건 표준오차 선형모형으로 수행합니다. MCI-CN 및 AD-CN 두 대비는 Holm 보정합니다. MCI 종단 분석은 `converted_to_ad_24m ~ corrected_BAG + age + sex + ICV` 로지스틱 회귀이며, 관찰자료의 연관성이지 인과관계나 개인별 전환 예측 확정이 아닙니다.

## 뇌 표면 지도

### 집단 BAG-연관 지도

68개 Desikan-Killiany 피질 두께 ROI에 대해 연령·성별·ICV를 고려한 CN 기준을 만들고, 임상 비교 코호트에서 BAG와의 연관성을 추정합니다. 빨간색은 BAG가 높을수록 상대적으로 더 얇은 피질과 연관된 방향이며, 다중 검정은 FDR q<0.05로 보정합니다. 동일 ROI가 뇌 연령 모델 입력에도 사용되므로 이 지도는 독립적인 인과적 병변 지도가 아니라 **모델-연관 집단 지도**입니다.

### 개인별 3D 지도

`modeling_data/adni_personal_modeling_cohort.csv`에는 모든 적격 RID의 첫 T1 검사와 모델 입력이 들어 있고, `adni_person_catalog.csv`에는 선택 UI용 RID·진단·연령·촬영일이 들어 있습니다. 노트북 하단에서 RID를 검색하고 선택하면 다음을 생성합니다.

- 전역 지표: 동일한 V3 뇌 연령 모델과 BAG 보정식으로 계산한 개인 corrected BAG
- 지역 지표: 같은 연령·성별 CN 기준에서의 68개 피질 두께 `thinning_z`
- 3D HTML: 빨강은 더 얇은 방향, 파랑은 더 두꺼운 방향의 개인 ROI 편차

현재 원본 ADNI CSV는 개인의 `lh/rh.pial` 표면 파일을 포함하지 않습니다. 그러므로 기본 HTML은 **표준 fsaverage5 표면에 개인 ROI를 투영한 그림**입니다. 개인의 실제 FreeSurfer `surf/lh.pial`, `surf/rh.pial`, `label/lh.aparc.annot`, `rh.aparc.annot`이 별도로 있다면 노트북의 `FREESURFER_SUBJECT_DIR` 설정으로 그 사람의 표면을 사용할 수 있습니다.

## 실행 방법

1. Python 3.14 커널 `adni-brain-age-py314`을 선택합니다.
2. 필요한 패키지가 없다면 V3 폴더에서 `python -m pip install -r requirements.txt`를 실행합니다.
3. `ADNI_Brain_Age_Gap_V3_Integrated.ipynb`를 열고 **Run All**을 실행합니다.
4. 마지막의 개인별 모델링 섹션에서 RID를 검색하고 `개인 3D 지도 생성`을 누릅니다.

노트북은 모델과 모든 산출물을 V3 내부에 생성합니다. `DEMO 파일`과 `MODELING` 폴더의 파일을 실행 시 참조하지 않으므로, V3 생성 이후에는 독립적으로 실행할 수 있습니다. 단, 원본 `ADNI_data` 폴더는 그대로 유지해야 합니다.
