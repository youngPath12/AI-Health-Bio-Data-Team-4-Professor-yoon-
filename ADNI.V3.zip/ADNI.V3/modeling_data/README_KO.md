# V3 개인 모델링 데이터

이 폴더의 CSV는 V3 노트북이 원본 ADNI T1 FreeSurfer 표에서 자동 생성합니다.

- `adni_personal_modeling_cohort.csv`: RID별 첫 적격 T1 검사 한 건과 뇌 연령 모델 입력 ROI입니다. 개인 BAG와 지역 thinning_z 계산에 사용됩니다.
- `adni_person_catalog.csv`: 개인 선택 UI에 표시할 RID, 진단, 촬영일, 연령, 성별입니다.
- `data_dictionary.csv`: 위 데이터의 각 열 의미와 사용 목적입니다.

포함 기준은 RID, 촬영일, 연령, 성별, 진단, V3 뇌 연령 모델의 모든 입력 열이 결측 없이 존재하는 검사입니다. 같은 RID의 반복 방문은 촬영일이 가장 이른 한 건만 남깁니다. 따라서 이 CSV의 RID 수가 원본 ADNI의 모든 RID 수와 같지 않을 수 있습니다.

이 파일에는 연구용 식별자와 개인 MRI 요약값이 포함될 수 있으므로 ADNI 자료 이용 및 재배포 제한을 준수해야 합니다.
