# BAG-연관 피질 노화 지도

## 빨간색의 의미

각 빨간 parcel은 보정 BAG가 1 표준편차 높을 때, 실제 연령·성별·ICV를 보정한 뒤 더 큰 피질 얇아짐 부담과 양의 연관성이 있음을 뜻합니다.
`07_bag_associated_cortical_aging_surface_fdr.png`은 다중비교 FDR q<0.05를 통과한 parcel만 표시합니다.
`08_bag_cortical_surface_3d_left.html`과 `08_bag_cortical_surface_3d_right.html`은 parcel 경계가 흰색 선으로 보이는 회전형 3D 표면입니다.

## 해석 제한

이 지도는 집단 수준 Desikan-Killiany atlas를 fsaverage5에 투영한 결과입니다. 개인 MRI, voxel 수준 지도, 임상 진단이 아닙니다.
동일 ROI가 brain-age 모델에 기여하므로 독립 인과 지역화가 아니라 모델-연관 지역 지도로 해석해야 합니다.
