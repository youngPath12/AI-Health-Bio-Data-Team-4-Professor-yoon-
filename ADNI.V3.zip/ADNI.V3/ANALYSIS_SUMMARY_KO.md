# ADNI Brain Age Gap V3 통합 결과

생성 시각: 2026-08-20 12:45:32

## 전처리 점검

- ComBat 처리된 FreeSurfer ROI를 사용했고, 필수 변수 완전성·비수치·RID 중복·RID 단위 분할 누수를 점검했다.
- 참가자별 최초 적격 T1만 사용해 반복 방문 누수를 막았고, 성별·ICV를 모델과 임상군 비교에 포함했다.
- 원자료에는 motion 또는 segmentation pass/fail 같은 영상 수준 QC 열이 없어, 통계적 극단값만으로 참가자를 자동 제거하지 않았다.

## 독립 CN 테스트 성능과 유의성

- 선택 모델: ElasticNet
- MAE 4.17년 (95% CI 3.66–4.71), RMSE 5.30년, R2 0.445
- R2는 효과크기이며 단독 p값이 아니다. 500회 연령 순열검정에서 R2 p=0.001996, MAE p=0.001996로 모델 성능은 우연 기준보다 **통계적으로 유의** 높다.
- 훈련 평균연령 기준선 MAE: 5.67년

## 임상군 및 MCI 결과

- MCI 대 CN 테스트 BAG 차이: 6.09년, Holm p=2.364e-22
- AD 대 CN 테스트 BAG 차이: 15.13년, Holm p=1.503e-89
- MCI 24개월 AD 전환: BAG 1년 증가당 OR 1.164 (95% CI 1.128–1.200), p=3.115e-22

## BAG-연관 피질 지도

- 피질 두께 parcel 68개를 검정했고 FDR q<0.05 양의 연관성이 65개였다.
- 가장 큰 양의 연관성 parcel 예: LH middletemporal, RH middletemporal, RH inferiorparietal, LH inferiorparietal, LH superiortemporal, RH superiortemporal
- 빨간색은 보정 BAG가 높을수록 규준 기대치보다 더 큰 피질 얇아짐 부담과 연관됨을 뜻한다.
- 동일 ROI가 brain-age 모델 입력에도 쓰였으므로, 이 지도는 모델-연관 지도이며 원인적 지역화나 개인 판독이 아니다.

## 제한

- ADNI 관찰자료이므로 인과 추론이나 개인 진단에 사용할 수 없고, 외부 코호트 검증이 필요하다.
- 뇌 표면은 표준 fsaverage5 atlas에 투영한 parcel 수준 그림이며 각 참가자의 원본 MRI 렌더링이 아니다.
