# Anaconda base Python 3.13.9 실행 검증

## 실행 환경

- Python: `C:\Users\inyou\anaconda3\python.exe`, Python 3.13.9
- Jupyter 커널: `ADNI Brain Age V3 (base Python 3.13.9)` / `adni-brain-age-v3-base-py3139`
- 패키지 핵심 버전: NumPy 2.4.6, pandas 3.0.3, scikit-learn 1.8.0, SciPy 1.18.0, statsmodels 0.14.6, patsy 1.0.2, nilearn 0.14.0, nibabel 5.4.2

## 실제 실행 결과

2026-08-20에 `ADNI_Brain_Age_Gap_V3_Integrated.ipynb`를 base Python 3.13.9 커널로 전체 실행했습니다.

- 코드 셀: 31개 실행
- 저장된 오류: 0개
- 한국어 글꼴 누락 경고: 0개
- 생성 확인: brain-age 모델, 개인 코호트 2,385명, RID 10 좌·우 3D HTML

## 필요한 호환성 조정

원래 V3는 Python 3.14.5를 엄격히 요구했으므로, 이 복사본에서는 환경 검사와 커널만 base Python 3.13.9로 변경했습니다. 분석 방법, 입력 데이터, 전처리, 모델, 통계, 그림 생성 코드는 유지했습니다.

base에 있던 patsy 1.0.1은 pandas 3 문자열 dtype을 처리하지 못해 scanner batch 민감도 분석에서 오류가 발생했습니다. V3 검증 조합과 같은 patsy 1.0.2 및 SciPy 1.18.0으로 맞춘 뒤 전체 실행이 완료됐습니다. 이 버전들은 `requirements.txt`에도 기록되어 있습니다.

## 실행 방법

VS Code에서 이 노트북을 열고 `ADNI Brain Age V3 (base Python 3.13.9)` 커널을 선택해 **Run All**을 실행합니다. 또는 `RUN_V3_BASE_PYTHON_3_13_9.bat`을 실행하면 같은 base Python으로 Jupyter 서버가 시작됩니다.
