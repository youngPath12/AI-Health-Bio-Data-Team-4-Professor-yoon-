@echo off
set "PROJECT_DIR=%~dp0"
"C:\Users\inyou\anaconda3\python.exe" -m notebook --notebook-dir="%PROJECT_DIR%"
