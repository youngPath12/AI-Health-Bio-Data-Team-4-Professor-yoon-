"""Configure the copied V3 notebook for Anaconda base Python 3.13.9."""

from pathlib import Path

import nbformat


PROJECT_DIR = Path(__file__).resolve().parent
NOTEBOOK = PROJECT_DIR / "ADNI_Brain_Age_Gap_V3_Integrated.ipynb"

notebook = nbformat.read(NOTEBOOK, as_version=4)
notebook.metadata["kernelspec"] = {
    "display_name": "ADNI Brain Age V3 (base Python 3.13.9)",
    "language": "python",
    "name": "adni-brain-age-v3-base-py3139",
}
notebook.metadata["language_info"] = {"name": "python", "version": "3.13.9"}

for cell in notebook.cells:
    if cell.cell_type != "code":
        continue
    cell.source = cell.source.replace(
        'PROJECT_DIR = DESKTOP / "ADNI.V3"',
        'PROJECT_DIR = DESKTOP / "ADNI.V3_Python_3.13.9_Base"',
    ).replace(
        'sns.set_theme(style="whitegrid", context="notebook")',
        'sns.set_theme(style="whitegrid", context="notebook", rc={"font.family": "Malgun Gothic", "axes.unicode_minus": False})',
    )

for cell in notebook.cells:
    if cell.cell_type == "code" and "EXPECTED_VERSIONS" in cell.source:
        cell.source = cell.source.replace(
            "if sys.version_info[:3] != (3, 14, 5):",
            "if sys.version_info[:3] != (3, 13, 9):",
        ).replace(
            "Python 3.14.5 is required.",
            "Anaconda base Python 3.13.9 is required.",
        ).replace(
            "Python 3.14.5 environment. Select the 'ADNI Brain Age (Python 3.14)' kernel, ",
            "Anaconda base Python 3.13.9 environment. Select the 'ADNI Brain Age V3 (base Python 3.13.9)' kernel, ",
        ).replace(
            "install V2/requirements.txt",
            "install this folder's requirements.txt",
        ).replace(
            "Environment check passed: Python 3.14.5",
            "Environment check passed: Anaconda base Python 3.13.9",
        )
        break
else:
    raise RuntimeError("Python environment validation cell was not found.")

# Keep the generated requirements file installable from the base environment.
for cell in notebook.cells:
    if cell.cell_type == "code" and "requirements = chr(10).join" in cell.source:
        start = cell.source.index("requirements = chr(10).join")
        end = cell.source.index("\n\nartifact_paths", start)
        requirements_block = '''requirements = chr(10).join([
    "# System requirement: Anaconda base Python 3.13.9. Python itself is not a pip package.",
    f"numpy=={np.__version__}", f"pandas=={pd.__version__}",
    f"scikit-learn=={sklearn.__version__}", f"statsmodels=={statsmodels.__version__}",
    f"patsy=={version('patsy')}", f"scipy=={version('scipy')}",
    f"matplotlib=={plt.matplotlib.__version__}", f"seaborn=={sns.__version__}", f"joblib=={joblib.__version__}",
    f"nilearn=={version('nilearn')}", f"nibabel=={version('nibabel')}", f"plotly=={version('plotly')}",
    f"ipywidgets=={version('ipywidgets')}", f"ipykernel=={version('ipykernel')}",
    f"nbformat=={version('nbformat')}", f"notebook=={version('notebook')}",
]) + chr(10)
(PROJECT_DIR / "requirements.txt").write_text(requirements, encoding="utf-8")'''
        cell.source = cell.source[:start] + requirements_block + cell.source[end:]
        break
else:
    raise RuntimeError("Requirements generation cell was not found.")

nbformat.write(notebook, NOTEBOOK)
print(f"Updated base Python 3.13.9 metadata: {NOTEBOOK.name}")
