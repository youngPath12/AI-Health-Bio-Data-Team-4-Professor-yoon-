# ADNI Brain Age Gap V2: BAG-연관 피질 노화 지도

이 폴더에는 기존 brain-age/BAG 분석, MCI 24개월 AD 전환 분석, 그리고 BAG와 연관된 피질 노화 부담의 뇌 표면 시각화를 한 개의 노트북으로 합친 V2 분석이 있습니다.

## 실행 방법

1. `ADNI_Brain_Age_Gap_V2_Regional_Surface_Map.ipynb`를 엽니다.
2. VS Code 오른쪽 위 커널 선택에서 `ADNI Brain Age (Python 3.14)`를 선택합니다.
3. 첫 실행 전에 필요한 패키지가 없으면 `%pip install -r requirements.txt`를 실행하고 커널을 재시작합니다.
4. `Run All`을 실행합니다. 최초 실행 때 fsaverage5 표면과 FreeSurfer annotation 파일을 `assets/`에 내려받습니다.

## 노트북에 포함된 분석

- T1 FreeSurfer ROI 전처리, CN 기반 brain-age 모델 학습과 BAG 보정
- 독립 CN 테스트 성능, 순열검정, CN/MCI/AD BAG 비교
- MCI 기준선 MRI의 24개월 내 AD 전환 탐색 분석
- 독립 CN 테스트 R2와 MAE의 500회 연령 순열검정
- 표형 데이터에서 가능한 결측·비수치·RID 누수·범위·극단값 전처리 감사
- BAG가 높을수록 더 얇아지는 피질 두께 parcel의 통계적 연관성 분석
- Desikan-Killiany parcel을 fsaverage5 좌·우반구 외측/내측 뇌 표면에 표시하는 그림

## 뇌 표면 그림 해석

- `outputs/figures/06_bag_associated_cortical_aging_surface.png`: 양의 BAG-피질 얇아짐 연관성을 모두 표시합니다.
- `outputs/figures/07_bag_associated_cortical_aging_surface_fdr.png`: 다중비교 FDR q<0.05를 통과한 양의 연관성만 표시합니다.
- `outputs/figures/08_bag_cortical_surface_3d_left.html` 및 `08_bag_cortical_surface_3d_right.html`: parcel 경계가 흰색 선으로 표시되는 회전형 3D 뇌 표면입니다.
- 빨간색이 진할수록, 실제 연령·성별·ICV를 보정한 뒤에도 BAG가 1 표준편차 높을 때 더 큰 피질 얇아짐 부담과 연관됩니다.
- 회색 영역은 양의 연관성이 없거나 FDR 기준을 통과하지 않은 parcel, 또는 atlas의 비피질 영역입니다.

## R2 해석

- R2는 예측 성능의 효과크기이며 그 값 하나만으로 유의/비유의를 판정하지 않습니다.
- 노트북은 독립 CN 테스트에서 관측 R2가 무작위로 섞은 연령으로 학습한 모델보다 큰지 500회 순열검정으로 평가합니다. 결과 p값은 `bag_calibration.json`과 통합 요약 파일에 저장됩니다.

## 주의

- 그림은 ADNI 집단 수준의 FreeSurfer ROI를 표준 fsaverage5 atlas에 투영한 것입니다. 개인 MRI 영상이나 voxel 수준 병변 지도는 아닙니다.
- 이 지도는 brain-age 모델에 사용한 동일한 ROI와 BAG의 연관성을 나타냅니다. 따라서 BAG를 설명하는 모델-연관/특성 지도이지, 독립적으로 특정 부위가 BAG를 원인적으로 만든다는 검증 결과는 아닙니다.
- 원자료에는 motion 또는 FreeSurfer segmentation pass/fail 같은 영상 수준 QC 열이 없습니다. 노트북은 표형 데이터에서 가능한 완전성·범위·RID 누수·극단값 점검을 수행하지만, 원본 MRI 기반 QC를 대신할 수는 없습니다.
- BAG는 연구용 지표이며 개인 진단이나 미래 치매 위험을 확정하지 않습니다.
- 관찰연구 결과이므로 BAG와 지역적 구조 변화의 인과관계를 의미하지 않습니다.
